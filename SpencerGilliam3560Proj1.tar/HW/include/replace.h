///////////////////////////////////////////////
//Spencer Gilliam
//Professor Mourning
//01/28/2019
//CS 3560
//////////////////////////////////////////////

#ifndef REPLACE_H
#define REPLACE_H

void replace(std::string & Data, std::string & goReplace, std::string & replacement); //Replace function

#endif